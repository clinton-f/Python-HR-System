import streamlit as st
import pandas as pd
import numpy as np



def app():
    st.title("Employee data goes under here.")

    # Info Alert
    st.info("Some info!")

    # Warning Alert
    st.warning("Text warning!")


    st.subheader("Employee Table:")


    with st.form(key="form1"):

        st.write(pd.DataFrame({
        'ID': [1, 2, 3, 4],
        'Employee': [10, 20, 30, 40],
        'Salary': [10, 20, 30, 40]}))

        data = pd.DataFrame({
        'ID': [1, 2, 3, 4],
        'Employee Name': ['Sam', 'Shawn', 'Brook', 'Lucy'],
        'Salary': [1021234, 222343, 32222, 42123]})

        st.table(data)

        firstname, emplSal = st.columns([2,2])
        firstname.text_input("Name:")
        emplSal.text_input("Salary:")


st.header('My header')

#Submit form
with st.form("my_form"):
    submit_empl = st.form_submit_button("Submit")
    if submit_empl:
        st.write("Successfully Submitted!")

def top_bar():
    button1, button2, button3, button4 = st.columns(4)
    with button1:
        #List All Button
        if st.button("List All"):
            st.write("List All")

    with button2:
        #Employees Button
        st.button("Employees")

    with button3:
        #Managers Button
        st.button("Managers")

    with button4:
        #Executives Button
        st.button("Executives")


    button5, button6, button7, button8 = st.columns(4)
    with button5:
        #Salary Button
        st.button("Highest Salary")

    with button6:
        #Payroll Button
        st.button("Generate Payroll")

    with button7:
        #List/Name Button
        st.button("List/Name")

    with button8:
        #List/Salary Button
        st.button("List/Salary")

top_bar()

button9, button10, button11 = st.columns(3)

with button9:
    #Load Button
    if st.button("Load Data Set"):
        app()

with button10:
    #Clear Button
    if st.button("Clear"):
        st.table(data).clear()

with button11:
    #Exit Button
    if st.button("Exit"):
        st.write("Exited")
